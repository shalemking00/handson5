import './App.css';
import Viewdata from './components/Showdata';

function App() {
  return (
    <div className="App">
      <Viewdata/>
    </div>
  );
}
export default App;
