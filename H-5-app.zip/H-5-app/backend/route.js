var express = require('express')
const { addEmployee, getEmployees, getEmployee } = require('./controller')
var router = express.Router()
router.get('/', getEmployees)
.get('/:id', getEmployee)
.post('/', addEmployee)

module.exports = router;